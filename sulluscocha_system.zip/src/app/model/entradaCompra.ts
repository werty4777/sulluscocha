export interface EntradaCompra{

idEntrada;
proveedor;
tipoComprobante;
numeroComprobante;
numeroOrdenCompra;
valeIngreso;
entregadoPor;
recibidoPorPersona;
observaciones;
estadoMovimiento;





}
export interface DetallesEntradaCompra{



}
