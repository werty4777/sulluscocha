export class UserProfile {

    name: string;
    lastName: string;
    photo: string;
    email:string;


}
