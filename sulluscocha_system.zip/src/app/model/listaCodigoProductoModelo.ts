export interface ListaCodigoProductoModelo{
codigo;
descripcion;
modelo;
marca;
color;
talla;
tipo;
cantidad?;
}

