export interface DatosBuscador {
    codigo:string;
    nombre: string;
    modelo: string;
    marca: string;
    color: string;
    talla: string;

}
